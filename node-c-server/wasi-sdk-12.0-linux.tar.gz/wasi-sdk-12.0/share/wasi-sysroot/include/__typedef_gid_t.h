#ifndef __wasilibc___typedef_gid_t_h
#define __wasilibc___typedef_gid_t_h

typedef unsigned gid_t;

#endif
